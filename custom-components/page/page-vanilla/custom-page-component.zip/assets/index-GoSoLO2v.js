(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity)
      fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy)
      fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous")
      fetchOpts.credentials = "omit";
    else
      fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function showUserInfo() {
  kf.client.showInfo(`Hi ${kf.user.Name}!`);
}
document.getElementById("error").style.display = "none";
function defaultLandingComponent() {
  let userName = window.kf.user.Name;
  document.getElementById("error").style.display = "none";
  document.getElementById("username").innerHTML = userName;
  document.getElementById("clickHere").addEventListener("click", () => showUserInfo());
}
function defaultErrorComponent() {
  document.getElementById("landingHero").style.display = "none";
}
let kf$1;
window.onload = async function() {
  kf$1 = await window.kf.initialise().catch((err) => {
    console.error("Error initializing kissflow", err);
    defaultErrorComponent();
  });
  window.kf = kf$1;
  kf$1.context.watchParams(function(data) {
    console.log("watch params data", data);
    document.getElementById("inputParameters").innerText = JSON.stringify(data);
  });
  defaultLandingComponent();
};
