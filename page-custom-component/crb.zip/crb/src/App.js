import { Fragment, useEffect, useState } from "react";
import KFSDK from "@kissflow/lowcode-client-sdk";

import { AvailableRoomList } from "./kf/room_list";

import "./App.css";

function App() {
  const [kf, setKf] = useState();

  useEffect(() => {
    setTimeout(() => {
      loadKfSdk();
    }, 3000);
  }, []);

  async function loadKfSdk() {
    let kf = await KFSDK.initialize();
    window.kf = kf;
    setKf(kf);
  }

  return <Fragment>{kf && <AvailableRoomList />}</Fragment>;
}

export default App;
