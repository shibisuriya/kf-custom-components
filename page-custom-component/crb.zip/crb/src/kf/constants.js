export const AMENTIES = {
  TV: "Tv",
  CHAIRS: "Chairs",
  BOARD: "Board",
  PROJECTER: "Projecter",
  AC: "AC",
  TABLE: "Table",
};
