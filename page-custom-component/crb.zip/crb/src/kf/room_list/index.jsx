import React, { useEffect, useState } from "react";
import { AMENTIES } from "../constants";

import "./style.css";

import chairIcon from "./icons/chair.svg";
import boardIcon from "./icons/board.svg";
import projecterIcon from "./icons/projecter.svg";
import tvIcon from "./icons/tv.svg";
import staticRoomImg from "./icons/Fiveseat.jpeg";

const RoomsList = [
  {
    Untitled_Field: "room001",
    Room_Name: "Room Covai",
    Size: 4,
    Addons: ["Chairs", "Board", "Projecter", "Tv"],
  },
  {
    Untitled_Field: "room002",
    Room_Name: "Room Nagai",
    Size: 8,
    Addons: ["Chairs", "Board"],
  },
  {
    Untitled_Field: "room003",
    Room_Name: "Room Chennai",
    Size: 6,
    Addons: ["Chairs", "Board"],
  },
  {
    Untitled_Field: "room004",
    Room_Name: "Room Theni",
    Size: 3,
    Addons: ["Chairs", "Board"],
  },
];

let BaseUrl = "";

export function AvailableRoomList() {
  let kf = window.kf;
  let { _id: accountId } = kf?.account || {};

  const [availableRoomsList, setAvailableRoomsList] = useState([]);
  const [selectedRoomId, setSelectedRoomId] = useState();
  const [isLoader, setIsLoader] = useState(true);

  useEffect(function fetchRoomsList() {
    try {
      fetchAvailableRooms();
    } catch (e) {
      setIsLoader(false);
    }
    return () => {};
  }, []);

  async function fetchAvailableRooms() {
    const booking_log_form_id = await kf.app.getVariable("booking_log_form_id");
    BaseUrl = await kf.app.getVariable("LIVE_URL");

    // payload

    let { startDateTime, endDateTime, teamSize } =
      (await kf.app.page.popup.getAllParameters()) || {};

    let DateTimeFilter = {
      OR: [
        {
          AND: [
            {
              LHSField: "Start_Date",
              LHSAttribute: null,
              Operator: "LESS_THAN_OR_EQUAL_TO",
              RHSType: "Value",
              RHSValue: startDateTime,
              RHSField: null,
              RHSAttribute: null,
              Id: "Condition-Pk6Edg",
            },
            {
              LHSField: "End_date",
              LHSAttribute: null,
              Operator: "GREATER_THAN_OR_EQUAL_TO",
              RHSType: "Value",
              RHSValue: startDateTime,
              RHSField: null,
              RHSAttribute: null,
              Id: "Condition-Pk6Edg",
            },
          ],
        },
        {
          AND: [
            {
              LHSField: "Start_Date",
              Operator: "LESS_THAN_OR_EQUAL_TO",
              RHSType: "Value",
              RHSValue: endDateTime,
              RHSField: null,
              LHSAttribute: null,
              RHSAttribute: null,
              Id: "Condition-Pk6Edg",
            },
            {
              LHSField: "End_date",
              LHSAttribute: null,
              Operator: "GREATER_THAN_OR_EQUAL_TO",
              RHSType: "Value",
              RHSValue: endDateTime,
              RHSField: null,
              RHSAttribute: null,
              Id: "Condition-Pk6Edg",
            },
          ],
        },
      ],
    };
    let payload = { Filter: DateTimeFilter };

    let fetchAllBookingLogUrl = `/form/2/${accountId}/${booking_log_form_id}/list?_application_id=Conference_Room_Booking_A00`;

    // api
    let occupiedRoomsList = await kf.api(fetchAllBookingLogUrl, {
      method: "post",
      body: JSON.stringify(payload),
    });

    const occupiedRoomsListId = [];
    for (var j = 0; j < occupiedRoomsList.Data.length; j++) {
      occupiedRoomsListId.push(occupiedRoomsList.Data[j].RoomId);
    }

    let Room_Filter = {
      AND: [
        {
          AND: [
            {
              LHSField: "Untitled_Field",
              Operator: "NOT_PART_OF",
              RHSType: "Value",
              RHSValue: occupiedRoomsListId,
              RHSField: null,
              LHSAttribute: null,
              RHSAttribute: null,
              Id: "Condition-Pk6GnM",
            },
            {
              LHSField: "Size",
              LHSAttribute: null,
              Operator: "GREATER_THAN_OR_EQUAL_TO",
              RHSType: "Value",
              RHSValue: teamSize,
              RHSField: null,
              RHSAttribute: null,
              Id: "Condition-Pk6GnM",
            },
          ],
        },
      ],
    };

    let room_payload = { Filter: Room_Filter };

    const Room_Master_Id = await kf.app.getVariable("Room_Master_URL");
    const room_master_sorted_view_id = await kf.app.getVariable(
      "room_master_sorted_list_id"
    );

    let fetchAllRoomLogUrl = `/form/2/${accountId}/${Room_Master_Id}/view/${room_master_sorted_view_id}/list?_application_id=Conference_Room_Booking_A00&page_size=500`;

    let availableRoomsList = await kf.api(fetchAllRoomLogUrl, {
      method: "post",
      body: JSON.stringify(room_payload),
    });

    console.log("occupiedRooms", occupiedRoomsList);
    console.log("availbleRooms", availableRoomsList);

    setAvailableRoomsList(availableRoomsList.Data);
    setIsLoader(false);
  }

  function getImageUrl(imgObj = {}, baseUrl) {
    return `${baseUrl}/upload/${imgObj.key}`;
  }

  async function onSelectRoom(room) {
    setSelectedRoomId(room.Untitled_Field);
    await kf.app.setVariable("bp_selected_room_id", room._id);
  }

  let availableRoomLength = availableRoomsList.length;

  return isLoader ? null : (
    <main
      className={`roomsList ${availableRoomLength === 0 ? "emptyState" : ""}`}
    >
      {availableRoomLength === 0 ? (
        <p style={{ fontSize: "16px" }}>
          No rooms available for selected time!
        </p>
      ) : (
        availableRoomsList.map((room, i) => {
          return (
            <Card
              key={room.Untitled_Field}
              selected={room.Untitled_Field === selectedRoomId}
              name={room.Room_Name}
              imgUrl={staticRoomImg || getImageUrl(room.Room_Image, BaseUrl)}
              amenties={room.Addons}
              roomSize={room.Size}
              onClick={() => onSelectRoom(room)}
            />
          );
        })
      )}
    </main>
  );
}

function Card({
  name,
  imgUrl,
  amenties = [],
  roomSize,
  onClick,
  selected = false,
}) {
  return (
    <div className={`roomCard ${selected ? "selected" : ""}`} onClick={onClick}>
      <img className="roomImage" src={imgUrl} alt={name} />
      <p className="roomName">{name}</p>
      <div className="amenties">
        {amenties?.map((item, i) => {
          return (
            <AmentiItem key={`${item}${i}`} name={item} value={roomSize} />
          );
        })}
      </div>
    </div>
  );
}

function AmentiItem({ name, value }) {
  function getAmenti(name, value) {
    switch (name) {
      case AMENTIES.CHAIRS:
        return {
          icon: chairIcon,
          caption: `${value} seats`,
        };
      case AMENTIES.BOARD:
        return {
          icon: boardIcon,
          caption: `Whiteboard`,
        };
      // case AMENTIES.AC:
      //   return { icon: acIcon, caption: `Whiteboard` };
      // case AMENTIES.TABLE:
      //   return { icon: tableIcon, caption: `Whiteboard` };
      case AMENTIES.PROJECTER:
        return { icon: projecterIcon, caption: `Projecter` };
      case AMENTIES.TV:
        return { icon: tvIcon, caption: `Tv` };
      default:
        return null;
    }
  }

  const amentiData = getAmenti(name, value);

  return !amentiData ? null : (
    <div className="amentiWrapper">
      <img
        className="cardIcon"
        src={amentiData.icon}
        alt={amentiData?.caption}
      />
      {amentiData.caption}
    </div>
  );
}
