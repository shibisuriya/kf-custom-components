(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
let kf$1 = window.kf;
function showUserInfo() {
  kf$1.client.showInfo(`Hi ${kf$1.user.Name}!`);
}
function defaultLandingComponent() {
  let userName = kf$1.user.Name;
  document.getElementById("root").innerHTML = `
		<div class='landingHero'>
			<div class='mainDiv'>
				<h1>Welcome, ${userName}</h1>
				<div>
					<p class='sampletext'>
						This is a sample custom component pre-loaded with the
						Kissflow SDK. <br> Edit <code>index.js</code> to make
						changes.
					</p>
					<p class='sampletext'>
						Click <a
							href='https://kissflow.github.io/lcnc-sdk-js/'
							target='_blank'>
							here
						</a> to read the SDK documentation.
					</p>
				</div>
				<div id="output2"></div>
				<button id="clickHere">Click me</button>
				<img src="kf.logo.png" width="120px" class='logo'></img>
			</div>
		</div>`;
  document.getElementById("clickHere").addEventListener("click", () => showUserInfo());
}
function defaultErrorComponent() {
  document.getElementById("root").innerHTML = `
		<div class='error'>
			<h1>Something went wrong</h1>
			<p>Please use this component within Kissflow platform.</p>
		</div>`;
}
let kf;
window.onload = async function() {
  kf = await window.kf.initialise().catch((err) => {
    console.error("Error initializing kissflow", err);
    defaultErrorComponent();
  });
  window.kf = kf;
  kf.context.watchParams(function(data) {
    console.log("watch params data", data);
    document.getElementById("output2").innerText = JSON.stringify(data);
  });
  defaultLandingComponent();
};
